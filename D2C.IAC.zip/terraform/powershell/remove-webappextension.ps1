#Logging in to Azure
$url = "https://login.microsoftonline.com/${env:ARM_TENANT_ID}/oauth2/v2.0/token"
$body = @{
    grant_type = "client_credentials"
    client_id = $env:ARM_CLIENT_ID
    client_secret = $env:ARM_CLIENT_SECRET
    scope = "https://graph.microsoft.com/.default"
}

try {
    $tokenrequest = Invoke-WebRequest -Method Post -Uri $url -ContentType "application/x-www-form-urlencoded" -Body $body -UseBasicParsing -ErrorAction Stop
}
catch {
    Write-Output $_.ErrorDetails
}

$token = ($tokenrequest.Content | ConvertFrom-Json).access_token
$bearerToken = "Bearer ${token}"
#Uninstall the extension using Rest API. Abort for any error other than "not found"
$headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$headers.Add("Authorization", $bearertoken)

$url = $env:APP_SERVICE_NAME+".scm.azurewebsites.net"
$uri = "https://$($url)/api/siteextensions/$($env:EXTENSION_NAME)"
try
{
    Write-Output "Deleting extension on the primary app service"
    Write-Output "Calling $uri"
    $req = Invoke-WebRequest $uri -Method 'DELETE' -Headers $headers -EA 0
    Write-Output "Removed $($req.StatusDescription)"
}
catch{
    $message = ($_.ErrorDetails.Message)
    Write-Output $message
    if ($message -Like "*not installed locally*") { 
        Write-Output "Exception: Failed to delete the extension"
        Write-Output $message
        exit 1 
    }
}

# Restarting the Kudu process (This always throws a 502 response even when successful)
$uri = "https://$($url)/api/processes/0"
try
{
    Write-Output "Restarting the primary app service at the kudu level"
    Write-Output "Calling $uri"
    Invoke-WebRequest $uri -Method 'DELETE' -Headers $headers
}
catch{}
