﻿
# Define the path to the SqlPackage.exe file
$SqlPackagePath = "C:\Program Files (x86)\Microsoft SQL Server\160\DAC\SqlPackage.exe"
$Env = "model"
# Define the server, user, and password
$serverName = "sql-d2cho3-$Env.database.windows.net"
$username = "aizadmin"
$password = "N%qkN4CTUx9RIKoM"
$inputFolder = "C:\Dev\HO3\SQL\$Env\backpac\"
$logFolder = "C:\Dev\HO3\SQL\$Env\backpac\importlogs"
$databaseList = @("d2cuserstate-condo", "d2cuserstate-ho3", "d2cuserstate-mh", "d2ccms-mh", "d2ccms-master", "d2ccms-ho3", "d2ccms")  

# Create the logs folder if it does not exist
if (-Not (Test-Path -Path $logFolder)) {
    New-Item -ItemType Directory -Path $logFolder
}

foreach ($database in $databaseList) {
    $inFile = Join-Path -Path $inputFolder -ChildPath "$database.bacpac"
    $logFile = Join-Path -Path $logFolder -ChildPath "$database.log"
    $errorLogFile = Join-Path -Path $logFolder -ChildPath "$database-error.log"
    
    $args = @(
        "/Action:Import",
        "/sf:$inFile",
		"/tsn:$serverName",
		"/tdn:$database",
		"/tu:$username",
		"/tp:$password"
    )
    
    # Start the background job with log redirection
    Write-Host "Starting import of database $database to $outputFile in background"
    Start-Job -ScriptBlock {
        param($exePath, $arguments, $log, $errorLog)
        & $exePath @arguments *>$log 2>$errorLog
    } -ArgumentList $SqlPackagePath, $args, $logFile, $errorLogFile
}

Write-Host "Background import jobs started for all databases."

# Wait for all background jobs to complete
$jobs = Get-Job
foreach ($job in $jobs) {
    Wait-Job -Job $job
    $jobDetails = Receive-Job -Job $job
    Write-Host "Job ID $($job.Id) completed with state: $($job.State)"
    Remove-Job -Job $job
}

Write-Host "Import completed for all databases. Logs are located in the $logFolder folder."