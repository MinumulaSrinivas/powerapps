$Server = 'sql-d2cho3-dev.database.windows.net'
$Env = "dev"
$UserAdmin = "aizadmin"
$PWD = "N0HDDOQzA3W%5uHg"
$Database = 'd2cuserstate-condo'
$databaseList = @("d2cuserstate-condo", "d2cuserstate-ho3", "d2cuserstate-mh", "d2ccms-mh", "d2ccms-master",, "d2ccms-ho3", "d2ccms") 
#$databaseList = @("d2cuserstate-condo") 
$userList = @( "mi-d2cho3-$Env") #"mi-d2cho3-eastus2",  #in dev we only have one
$Port = 1433

foreach ($database in $databaseList) {
    foreach ($user in $userList){
        $cxnString = "Server=tcp:$Server,$Port;Database=$database;UID=$UserAdmin;PWD=$PWD;Trusted_Connection=False;Encrypt=True;Connection Timeout=30;"
        $cxn = New-Object System.Data.SqlClient.SqlConnection($cxnString)
        $cxn.Open()        
        #$query = "CREATE USER [sample-$user] WITH PASSWORD = 'JRxuerCc(q'"
        $query = "
            create user [$user] from  external provider;
            alter role db_datareader add member [$user];
            alter role db_datawriter add member [$user];
            alter role db_ddladmin add member [$user];
            alter user [$user-$env] with default_schema = dbo;
        "
        $cmd = New-Object System.Data.SqlClient.SqlCommand($query, $cxn)
        $cmd.CommandTimeout = 120
        $cmd.ExecuteNonQuery()    
        $cxn.Close()
    }    
}
