# Create base64 certificate
# dev:
$env = "dev"
$fileName= "kv-d2cho3-dev-p6ylvq0n-devDOTassuranthomeinsuranceDOTcom-PFX-20250210"
$fileLocation= "C:\Dev\HO3\terraform\Keyvault\$env\"
$file= "$fileLocation\$fileName.pfx"
$fileContentBytes= get-content $file -Encoding Byte
[System.Convert]::ToBase64String($fileContentBytes) | Out-File "$fileLocation\$fileName.txt"